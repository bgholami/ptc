#define __MPI
#define __FFTW
