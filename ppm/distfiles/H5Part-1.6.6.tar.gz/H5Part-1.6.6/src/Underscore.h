#ifndef F77_SINGLE_UNDERSCORE
#define F77_SINGLE_UNDERSCORE
#endif
#ifndef F77_NO_CAPS
#define F77_NO_CAPS
#endif
