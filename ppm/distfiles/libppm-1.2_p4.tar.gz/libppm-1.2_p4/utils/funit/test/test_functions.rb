require 'test/unit'
require 'funit/functions'

class TestFunctions < Test::Unit::TestCase

  def test_something
    # FIXME
  end

end
